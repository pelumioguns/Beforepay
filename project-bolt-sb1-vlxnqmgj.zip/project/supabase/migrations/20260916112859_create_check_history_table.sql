/*
# Create check_history table for BeforePay

1. New Tables
- `check_history`
  - `id` (uuid, primary key)
  - `input_type` (text, not null) — the type of content checked: 'message', 'phone', 'website', 'payment'
  - `input_content` (text, not null) — the text the user submitted for analysis
  - `risk_score` (integer, not null) — overall risk score 0-100
  - `risk_level` (text, not null) — 'low', 'moderate', 'high', or 'critical'
  - `findings_count` (integer, not null default 0) — number of red flags found
  - `findings` (jsonb) — array of finding objects with category, severity, title, description, recommendation
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `check_history`.
- This is a single-tenant app with no sign-in screen, so all CRUD is allowed for anon + authenticated.
- `USING (true)` is acceptable because the data is intentionally public/shared (no auth, no user isolation).

3. Indexes
- Index on `created_at` for history listing queries.
*/

CREATE TABLE IF NOT EXISTS check_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  input_type text NOT NULL,
  input_content text NOT NULL,
  risk_score integer NOT NULL,
  risk_level text NOT NULL,
  findings_count integer NOT NULL DEFAULT 0,
  findings jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE check_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_check_history" ON check_history;
CREATE POLICY "anon_select_check_history" ON check_history FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_check_history" ON check_history;
CREATE POLICY "anon_insert_check_history" ON check_history FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_check_history" ON check_history;
CREATE POLICY "anon_delete_check_history" ON check_history FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_check_history_created_at ON check_history (created_at DESC);
