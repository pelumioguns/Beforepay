export type InputType = 'message' | 'phone' | 'website' | 'payment';

export type RiskLevel = 'low' | 'moderate' | 'high' | 'critical';

export interface Finding {
  category: string;
  severity: 'info' | 'warning' | 'danger';
  title: string;
  description: string;
  recommendation: string;
}

export interface AnalysisResult {
  inputType: InputType;
  inputContent: string;
  riskScore: number;
  riskLevel: RiskLevel;
  findings: Finding[];
  summary: string;
}

export interface CheckHistoryItem {
  id: string;
  input_type: string;
  input_content: string;
  risk_score: number;
  risk_level: string;
  findings_count: number;
  findings: Finding[];
  created_at: string;
}
