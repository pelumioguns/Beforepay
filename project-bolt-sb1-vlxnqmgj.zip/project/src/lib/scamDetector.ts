import type { AnalysisResult, Finding, InputType, RiskLevel } from '@/types';

interface Rule {
  category: string;
  severity: 'info' | 'warning' | 'danger';
  title: string;
  description: string;
  recommendation: string;
  patterns: RegExp[];
  weight: number;
}

const urgencyPhrases = [
  /act\s+now/i, /immediately/i, /right\s+now/i, /urgent/i, /asap/i,
  /expires?\s+(today|in\s+\d+\s+hours?|in\s+\d+\s+minutes?)/i,
  /final\s+(notice|warning|chance|reminder)/i,
  /last\s+(chance|opportunity|warning)/i,
  /don'?t\s+(miss|wait|delay)/i,
  /limited\s+time/i, /offer\s+ends?\s+(today|soon|shortly)/i,
  /within\s+\d+\s+hours?/i, /before\s+it'?s\s+too\s+late/i,
  /time[-\s]?sensitive/i, /deadline/i,
];

const moneyPhrases = [
  /wire\s+transfer/i, /western\s+union/i, /moneygram/i, /money\s+order/i,
  /gift\s+cards?/i, /itunes?\s+card/i, /google\s+play\s+card/i,
  /amazon\s+card/i, /steam\s+card/i, /prepaid\s+card/i,
  /bitcoin/i, /crypto/i, /ethereum/i, /usdt/i, /tether/i,
  /bank\s+transfer/i, /zelle/i, /venmo/i, /cashapp/i, /cash\s+app/i,
];

const authorityPhrases = [
  /IRS/i, /\bIRS\b/i, /tax\b/i, /social\s+security/i, /\bSSN\b/i,
  /police/i, /\bFBI\b/i, /\bCIA\b/i, /government/i, /federal/i,
  /treasury/i, /court/i, /arrest/i, /warrant/i, /lawsuit/i,
  /deport/i, /immigration/i, /customs/i, /\bICE\b/i,
  /medicare/i, /medicaid/i, /police\s+department/i, /sheriff/i,
];

const impersonationPhrases = [
  /I\s+am\s+(a|an)\s+(officer|agent|representative|official|supervisor|manager|director)/i,
  /this\s+is\s+(the|your)\s+(bank|government|IRS|police|FBI|agency|department)/i,
  /on\s+behalf\s+of/i, /authorized\s+representative/i,
  /official\s+(notice|communication|message|letter)/i,
];

const secrecyPhrases = [
  /don'?t\s+tell\s+(anyone|your\s+(family|husband|wife|spouse|kids?|parents?))/i,
  /keep\s+this\s+(secret|confidential|private|between\s+us)/i,
  /don'?t\s+share\s+this/i, /between\s+you\s+and\s+me/i,
  /tell\s+no\s+one/i, /do\s+not\s+discuss/i,
  /discreet/i, /confidential\s+matter/i,
];

const emotionalPhrases = [
  /you'?ve\s+won/i, /congratulations/i, /winner/i, /selected/i, /chosen/i,
  /lottery/i, /sweepstakes/i, /prize/i, /jackpot/i,
  /inheritance/i, /beneficiary/i, /next\s+of\s+kin/i,
  /unclaimed\s+funds?/i, /dormant\s+account/i,
  /refugee/i, /stranded/i, /orphan/i, /widow/i,
  /love\s+you/i, /my\s+(dear|darling|sweetheart)/i,
  /can'?t\s+stop\s+thinking\s+about\s+you/i,
];

const credentialPhrases = [
  /password/i, /PIN\b/i, /\bCVV\b/i, /social\s+security\s+number/i,
  /\bSSN\b/i, /account\s+number/i, /routing\s+number/i,
  /verification\s+code/i, /OTP\b/i, /one[-\s]?time\s+(password|code|pin)/i,
  /login\s+credentials?/i, /security\s+(question|answer)/i,
  /mother'?s\s+maiden\s+name/i, /date\s+of\s+birth/i,
  /\bDOB\b/i, /full\s+name\s+and\s+address/i,
];

const suspiciousUrlPatterns = [
  /https?:\/\/(bit\.ly|tinyurl|t\.co|goo\.gl|ow\.ly|is\.gd|buff\.ly|rebrand\.ly|cutt\.ly|shorturl)/i,
  /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/, // raw IP
  /[a-z0-9-]+\.(tk|ml|ga|cf|gq|xyz|top|click|country|stream|online|site|live|buzz|fun|icu)\b/i,
  /https?:\/\/[a-z0-9-]+\.[a-z]{2,}\/[a-z0-9]{20,}/i, // long random path
];

const suspiciousPhonePatterns = [
  /\+?\d{10,15}/, // any long number
  /1-?\d{3}-?\d{3}-?\d{4}/, // US toll-style
  /0\d{2,4}\s?\d{6,8}/, // UK-style
  /\b8\d{2}\s?\d{3}\s?\d{4}\b/, // 8xx numbers
];

const grammarRedFlags = [
  /dear\s+(sir|madam|valued\s+customer|user|account\s+holder)/i,
  /I\s+am\s+(writing|contacting)\s+you\s+(from|on\s+behalf)/i,
  /kindly\s+(send|provide|reply|confirm|forward|do\s+the\s+needful)/i,
  /do\s+the\s+needful/i,
  /awaiting\s+your\s+(prompt\s+)?response/i,
  /warm\s+regards/i, /yours\s+faithfully/i,
  /\bpls\b/i, /\bplz\b/i, /\bkindly\b/i,
  /(.)\1{3,}/, // repeated characters
];

const investmentScamPhrases = [
  /guaranteed\s+(return|profit|income|earnings?)/i,
  /risk[-\s]?free\s+(investment|return|profit)/i,
  /double\s+your\s+(money|investment|crypto)/i,
  /get\s+rich\s+quick/i,
  /high\s+return/i, /low\s+risk/i,
  /forex\s+trading/i, /binary\s+options?/i,
  /pump\s+and\s+dump/i, /moon\s+(soon|incoming)/i,
  /ROI\s+of\s+\d+/i, /\d+%\s+(return|profit|ROI|APY|APR)/i,
  /passive\s+income/i, /financial\s+freedom/i,
];

const jobScamPhrases = [
  /work\s+from\s+home/i, /easy\s+money/i, /no\s+experience\s+(needed|required|necessary)/i,
  /earn\s+\$?\d{3,}.*(week|day|hour)/i,
  /mystery\s+shopper/i, /secret\s+shopper/i,
  /package\s+(forwarding|reshipping)/i, /reshipping/i,
  /personal\s+assistant/i, /virtual\s+assistant/i,
  /data\s+entry/i, /envelope\s+stuffing/i,
  /pay\s+(upfront|in\s+advance|a\s+fee)/i,
  /processing\s+fee/i, /training\s+fee/i, /materials?\s+fee/i,
  /background\s+check\s+fee/i,
];

const romanceScamPhrases = [
  /I\s+(am|was)\s+(deployed|stationed)\s+(in|over)/i,
  /military\s+(man|woman|soldier|officer)/i,
  /oil\s+rig/i, /offshore/i, /widow(?:er)?\s+(with|and)/i,
  /god\s+fearing/i, /honest\s+and\s+faithful/i,
  /I\s+(will|would)\s+love\s+to\s+(meet|see|visit)\s+you/i,
  /send\s+me\s+(money|funds|a\s+(phone|laptop|gift|card))/i,
  /video\s+call\s+(isn'?t|is\s+not|can'?t)\s+(possible|working|available)/i,
  /my\s+(phone|camera|laptop)\s+is\s+(broken|damaged|not\s+working)/i,
];

const rules: Rule[] = [
  {
    category: 'Urgency & Pressure',
    severity: 'danger',
    title: 'Creates artificial urgency or panic',
    description: 'This message tries to make you act fast without thinking. Scammers use time pressure so you don\'t have time to verify their claims or consult someone you trust.',
    recommendation: 'Slow down. Real organizations give you time to make decisions. Take a breath and verify independently before doing anything.',
    patterns: urgencyPhrases,
    weight: 15,
  },
  {
    category: 'Payment Method',
    severity: 'danger',
    title: 'Requests untraceable or irreversible payment methods',
    description: 'Asking for gift cards, crypto, wire transfers, or money apps is a major red flag. These methods are nearly impossible to reverse once the money is sent.',
    recommendation: 'Never pay with gift cards, cryptocurrency, or wire transfers to someone you don\'t know in person. Legitimate organizations don\'t ask for these.',
    patterns: moneyPhrases,
    weight: 20,
  },
  {
    category: 'Authority Impersonation',
    severity: 'danger',
    title: 'Claims to be from a government agency or authority',
    description: 'Scammers frequently impersonate the IRS, police, FBI, or other government bodies to intimidate you into complying. Real agencies don\'t contact you this way.',
    recommendation: 'Government agencies will never call, text, or email you demanding immediate payment or personal information. Hang up and contact the agency directly using their official website or phone number.',
    patterns: authorityPhrases,
    weight: 18,
  },
  {
    category: 'Impersonation',
    severity: 'warning',
    title: 'Claims an official identity without verifiable proof',
    description: 'The sender claims to represent an organization but provides no way to independently verify their identity. This is a common tactic to gain your trust.',
    recommendation: 'Do not trust the sender\'s claimed identity. Contact the organization directly using a phone number or website you find independently — not one provided in the message.',
    patterns: impersonationPhrases,
    weight: 12,
  },
  {
    category: 'Secrecy',
    severity: 'danger',
    title: 'Asks you to keep this a secret',
    description: 'Legitimate transactions and communications don\'t require secrecy. Asking you to hide something from family or friends is a manipulation tactic to prevent you from getting advice that could expose the scam.',
    recommendation: 'Talk to someone you trust about this. Anyone asking you to keep a financial matter secret is likely trying to scam you.',
    patterns: secrecyPhrases,
    weight: 16,
  },
  {
    category: 'Too Good to Be True',
    severity: 'danger',
    title: 'Promises money, prizes, or emotional rewards',
    description: 'Messages about lottery wins, inheritances, prizes, or sudden romantic devotion are designed to trigger excitement or hope so you let your guard down.',
    recommendation: 'You can\'t win a lottery you didn\'t enter. Inheritances come through legal channels, not random messages. Be skeptical of any unexpected windfall.',
    patterns: emotionalPhrases,
    weight: 14,
  },
  {
    category: 'Credential Harvesting',
    severity: 'danger',
    title: 'Requests sensitive personal or financial information',
    description: 'Asking for passwords, PINs, Social Security numbers, verification codes, or banking details is a hallmark of phishing. Real organizations never ask for these via message.',
    recommendation: 'Never share passwords, PINs, one-time codes, or full SSNs via text, email, or phone. If asked, it is almost certainly a scam.',
    patterns: credentialPhrases,
    weight: 18,
  },
  {
    category: 'Suspicious Link',
    severity: 'danger',
    title: 'Contains shortened or suspicious URLs',
    description: 'Shortened links, raw IP addresses, and unusual domain extensions are used to hide the real destination. Clicking them can lead to fake websites that steal your information.',
    recommendation: 'Do not click any links in this message. If you need to visit a website, type the official URL directly into your browser.',
    patterns: suspiciousUrlPatterns,
    weight: 16,
  },
  {
    category: 'Phone Number Risk',
    severity: 'warning',
    title: 'Contains a phone number for contact',
    description: 'Scammers often include phone numbers to move you to a private conversation where they can apply more pressure. The number may be spoofed or from a scam operation.',
    recommendation: 'Do not call the number. If you need to contact an organization, use the number from their official website or the back of your card.',
    patterns: suspiciousPhonePatterns,
    weight: 8,
  },
  {
    category: 'Language & Grammar',
    severity: 'warning',
    title: 'Uses scam-typical language patterns',
    description: 'Certain phrases and grammar patterns are commonly used in scam messages. Professional organizations typically communicate with proper grammar and standard business language.',
    recommendation: 'Be cautious. The informal or formulaic language in this message is a common characteristic of scam communications, especially those originating overseas.',
    patterns: grammarRedFlags,
    weight: 6,
  },
  {
    category: 'Investment Fraud',
    severity: 'danger',
    title: 'Promises guaranteed or unrealistic investment returns',
    description: 'Guaranteed high returns with low risk don\'t exist. Any investment opportunity promising guaranteed profits or risk-free earnings is a scam.',
    recommendation: 'All investments carry risk. Never invest based on an unsolicited message. Consult a licensed financial advisor and verify the investment through official regulators.',
    patterns: investmentScamPhrases,
    weight: 17,
  },
  {
    category: 'Job Scam',
    severity: 'danger',
    title: 'Offers unrealistic employment or asks for upfront payment',
    description: 'Jobs that require no experience but offer high pay, or that ask you to pay upfront for materials, training, or background checks, are almost always scams.',
    recommendation: 'Never pay money to get a job. Legitimate employers don\'t ask for fees. Research the company independently and verify the job posting on official job boards.',
    patterns: jobScamPhrases,
    weight: 15,
  },
  {
    category: 'Romance Scam',
    severity: 'danger',
    title: 'Shows signs of a romance or relationship scam',
    description: 'Quick declarations of love, inability to video call, claims of military deployment or working on an oil rig, and eventual requests for money are classic romance scam patterns.',
    recommendation: 'Be very cautious. Do not send money to someone you haven\'t met in person. Reverse-image-search their photos. Romance scammers invest weeks or months before asking for money.',
    patterns: romanceScamPhrases,
    weight: 16,
  },
];

function detectInputType(text: string): InputType {
  if (/https?:\/\//i.test(text) || /\.(com|org|net|io|co|gov|edu|uk|au|ca|de|fr|tk|ml|ga|cf|gq|xyz)\b/i.test(text)) {
    return 'website';
  }
  if (/^[\+]?[\d\s\-\(\)]{7,}$/.test(text.trim()) && /\d{7,}/.test(text.replace(/\D/g, ''))) {
    return 'phone';
  }
  if (/\$\s*\d|payment|pay\s|invoice|receipt|transfer|deposit|fee|charge/i.test(text)) {
    return 'payment';
  }
  return 'message';
}

function calculateRiskScore(findings: Finding[], rulesMatched: Rule[]): number {
  let score = 0;
  for (const rule of rulesMatched) {
    score += rule.weight;
  }
  return Math.min(score, 100);
}

function getRiskLevel(score: number): RiskLevel {
  if (score >= 70) return 'critical';
  if (score >= 45) return 'high';
  if (score >= 20) return 'moderate';
  return 'low';
}

function generateSummary(score: number, level: RiskLevel, findings: Finding[], inputType: InputType): string {
  const typeLabel = {
    message: 'message',
    phone: 'phone number',
    website: 'website or link',
    payment: 'payment request',
  }[inputType];

  if (level === 'critical') {
    return `This ${typeLabel} shows critical scam warning signs. We found ${findings.length} red flag${findings.length === 1 ? '' : 's'}. Do not send money, share information, or click any links. Stop and verify independently before taking any action.`;
  }
  if (level === 'high') {
    return `This ${typeLabel} has multiple scam warning signs. We found ${findings.length} red flag${findings.length === 1 ? '' : 's'}. Be very cautious and verify independently before proceeding. Do not send money or share personal information.`;
  }
  if (level === 'moderate') {
    return `This ${typeLabel} has some suspicious elements. We found ${findings.length} warning sign${findings.length === 1 ? '' : 's'}. Take time to verify the source before taking any action. When in doubt, ask someone you trust.`;
  }
  return `This ${typeLabel} didn't trigger major scam warning signs, but stay alert. Scammers constantly change tactics, so always use your judgment. If something feels off, trust your instincts and verify independently.`;
}

export function analyzeInput(text: string): AnalysisResult {
  const trimmed = text.trim();
  const inputType = detectInputType(trimmed);
  const matchedRules: Rule[] = [];
  const findings: Finding[] = [];

  for (const rule of rules) {
    for (const pattern of rule.patterns) {
      if (pattern.test(trimmed)) {
        if (!matchedRules.includes(rule)) {
          matchedRules.push(rule);
          findings.push({
            category: rule.category,
            severity: rule.severity,
            title: rule.title,
            description: rule.description,
            recommendation: rule.recommendation,
          });
        }
        break;
      }
    }
  }

  const riskScore = calculateRiskScore(findings, matchedRules);
  const riskLevel = getRiskLevel(riskScore);
  const summary = generateSummary(riskScore, riskLevel, findings, inputType);

  return {
    inputType,
    inputContent: trimmed,
    riskScore,
    riskLevel,
    findings,
    summary,
  };
}
