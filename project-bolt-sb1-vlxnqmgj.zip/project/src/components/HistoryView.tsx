import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import type { CheckHistoryItem } from '@/types';
import { History, Trash2, ArrowRight, ShieldAlert, ShieldCheck, ShieldX, Shield, ChevronRight, Inbox } from 'lucide-react';

type View = 'home' | 'checker' | 'results' | 'history' | 'education';

interface Props {
  onNavigate: (view: View) => void;
  onSelectResult: (item: CheckHistoryItem) => void;
}

const levelIcons: Record<string, typeof Shield> = {
  low: ShieldCheck,
  moderate: Shield,
  high: ShieldAlert,
  critical: ShieldX,
};

const levelColors: Record<string, string> = {
  low: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
  moderate: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
  high: 'text-orange-400 bg-orange-500/10 border-orange-500/30',
  critical: 'text-red-400 bg-red-500/10 border-red-500/30',
};

function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins} min ago`;
  if (diffHours < 24) return `${diffHours} hr ago`;
  if (diffDays < 7) return `${diffDays} day${diffDays === 1 ? '' : 's'} ago`;
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export default function HistoryView({ onNavigate, onSelectResult }: Props) {
  const [items, setItems] = useState<CheckHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('check_history')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);

    if (error) {
      setError('Could not load history.');
    } else {
      setItems(data || []);
    }
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('check_history').delete().eq('id', id);
    if (!error) {
      setItems(items.filter((item) => item.id !== id));
    }
  };

  const handleClearAll = async () => {
    const { error } = await supabase.from('check_history').delete().neq('id', '00000000-0000-0000-0000-000000000000');
    if (!error) {
      setItems([]);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <div className="max-w-3xl mx-auto px-5 pt-8 pb-20">
        <button
          onClick={() => onNavigate('checker')}
          className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-8 text-sm font-medium"
        >
          <ArrowRight className="w-4 h-4 rotate-180" />
          Back to checker
        </button>

        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center">
              <History className="w-6 h-6 text-cyan-400" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Check History</h1>
              <p className="text-slate-500 text-sm">Everything you've checked with BeforePay</p>
            </div>
          </div>
          {items.length > 0 && (
            <button
              onClick={handleClearAll}
              className="text-slate-500 hover:text-red-400 text-sm font-medium transition-colors"
            >
              Clear all
            </button>
          )}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-slate-700 border-t-cyan-500 rounded-full animate-spin" />
          </div>
        ) : error ? (
          <div className="text-center py-20 text-slate-400">{error}</div>
        ) : items.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 rounded-2xl bg-slate-800/50 flex items-center justify-center mx-auto mb-4">
              <Inbox className="w-8 h-8 text-slate-600" />
            </div>
            <h3 className="text-white text-lg font-semibold mb-2">No checks yet</h3>
            <p className="text-slate-500 text-sm mb-6">Your check history will appear here once you start checking things.</p>
            <button
              onClick={() => onNavigate('checker')}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold px-6 py-3 rounded-xl hover:shadow-lg hover:shadow-cyan-500/25 transition-all"
            >
              <Shield className="w-5 h-5" />
              Check Something
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {items.map((item) => {
              const Icon = levelIcons[item.risk_level] || Shield;
              const colorClass = levelColors[item.risk_level] || 'text-slate-400 bg-slate-800';
              return (
                <div
                  key={item.id}
                  className="group bg-slate-900/60 border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition-all"
                >
                  <div className="flex items-start gap-4">
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border ${colorClass}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0 cursor-pointer" onClick={() => onSelectResult(item)}>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-slate-500 text-xs uppercase tracking-wider">{item.input_type}</span>
                        <span className="text-slate-700 text-xs">·</span>
                        <span className="text-slate-500 text-xs">{formatDate(item.created_at)}</span>
                      </div>
                      <p className="text-white text-sm font-medium truncate mb-1">
                        {item.input_content.length > 120
                          ? item.input_content.slice(0, 120) + '...'
                          : item.input_content}
                      </p>
                      <div className="flex items-center gap-3 text-xs">
                        <span className={`font-semibold ${colorClass.split(' ')[0]}`}>
                          {item.risk_level}
                        </span>
                        <span className="text-slate-600">·</span>
                        <span className="text-slate-500">Score: {item.risk_score}/100</span>
                        <span className="text-slate-600">·</span>
                        <span className="text-slate-500">{item.findings_count} finding{item.findings_count === 1 ? '' : 's'}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => onSelectResult(item)}
                        className="p-2 rounded-lg text-slate-500 hover:text-white hover:bg-slate-800 transition-colors"
                        aria-label="View details"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(item.id)}
                        className="p-2 rounded-lg text-slate-500 hover:text-red-400 hover:bg-slate-800 transition-colors"
                        aria-label="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
