import { useState, useRef, useEffect } from 'react';
import { analyzeInput } from '@/lib/scamDetector';
import { supabase } from '@/lib/supabase';
import type { AnalysisResult } from '@/types';
import { Shield, ShieldAlert, ShieldCheck, ShieldX, AlertTriangle, CheckCircle2, ArrowRight, Lightbulb, X, Clock, History, BookOpen, ChevronRight } from 'lucide-react';

type View = 'home' | 'checker' | 'results' | 'history' | 'education';
type InputType = 'message' | 'phone' | 'website' | 'payment';

interface Props {
  onNavigate: (view: View) => void;
  onAnalysisComplete: (result: AnalysisResult) => void;
}

const inputTypes: { type: InputType; label: string; placeholder: string; icon: typeof Shield }[] = [
  { type: 'message', label: 'Message', placeholder: 'Paste the full message you received — email, text, DM, chat...', icon: Shield },
  { type: 'phone', label: 'Phone Number', placeholder: 'Enter the phone number that contacted you...', icon: Shield },
  { type: 'website', label: 'Website / Link', placeholder: 'Paste the website URL or link you were sent...', icon: Shield },
  { type: 'payment', label: 'Payment Request', placeholder: 'Paste the payment request, invoice, or demand...', icon: Shield },
];

export default function Checker({ onNavigate, onAnalysisComplete }: Props) {
  const [input, setInput] = useState('');
  const [selectedType, setSelectedType] = useState<InputType | 'auto'>('auto');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [input]);

  const handleAnalyze = async () => {
    if (!input.trim()) {
      setError('Please paste something to check first.');
      return;
    }
    setError(null);
    setIsAnalyzing(true);

    try {
      const result = analyzeInput(input);

      await supabase.from('check_history').insert({
        input_type: result.inputType,
        input_content: result.inputContent,
        risk_score: result.riskScore,
        risk_level: result.riskLevel,
        findings_count: result.findings.length,
        findings: result.findings,
      });

      onAnalysisComplete(result);
      onNavigate('results');
    } catch (err) {
      setError('Something went wrong while analyzing. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleClear = () => {
    setInput('');
    setError(null);
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <div className="max-w-3xl mx-auto px-5 pt-8 pb-20">
        <button
          onClick={() => onNavigate('home')}
          className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-8 text-sm font-medium"
        >
          <ArrowRight className="w-4 h-4 rotate-180" />
          Back to home
        </button>

        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 mb-5 shadow-lg shadow-cyan-500/20">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3 tracking-tight">
            Check Before You Send
          </h1>
          <p className="text-slate-400 text-lg max-w-xl mx-auto">
            Paste a suspicious message, phone number, website, or payment request. We'll look for common scam warning signs and explain what to watch out for.
          </p>
        </div>

        <div className="bg-slate-900/60 backdrop-blur border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl">
          <div className="flex flex-wrap gap-2 mb-5">
            <button
              onClick={() => setSelectedType('auto')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                selectedType === 'auto'
                  ? 'bg-cyan-500 text-white shadow-lg shadow-cyan-500/20'
                  : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
              }`}
            >
              Auto-detect
            </button>
            {inputTypes.map(({ type, label }) => (
              <button
                key={type}
                onClick={() => setSelectedType(type)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  selectedType === type
                    ? 'bg-cyan-500 text-white shadow-lg shadow-cyan-500/20'
                    : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="relative">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={
                selectedType === 'auto'
                  ? 'Paste anything suspicious — a message, phone number, website link, or payment request...'
                  : inputTypes.find((t) => t.type === selectedType)?.placeholder
              }
              rows={6}
              className="w-full bg-slate-950/50 text-white placeholder-slate-600 rounded-xl border border-slate-800 px-5 py-4 text-base resize-none focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all min-h-[160px]"
            />
            {input && (
              <button
                onClick={handleClear}
                className="absolute top-3 right-3 p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
                aria-label="Clear input"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {error && (
            <div className="mt-4 flex items-center gap-2 text-red-400 text-sm">
              <AlertTriangle className="w-4 h-4" />
              {error}
            </div>
          )}

          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <button
              onClick={handleAnalyze}
              disabled={isAnalyzing || !input.trim()}
              className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold py-3.5 rounded-xl hover:shadow-lg hover:shadow-cyan-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isAnalyzing ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <ShieldCheck className="w-5 h-5" />
                  Check It Now
                </>
              )}
            </button>
            <button
              onClick={() => onNavigate('history')}
              className="flex items-center justify-center gap-2 bg-slate-800 text-slate-300 font-medium px-5 py-3.5 rounded-xl hover:bg-slate-700 transition-all"
            >
              <History className="w-5 h-5" />
              History
            </button>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            { icon: ShieldAlert, title: 'Urgency', desc: 'Pressure to act fast' },
            { icon: ShieldX, title: 'Payment', desc: 'Gift cards, crypto, wires' },
            { icon: AlertTriangle, title: 'Impersonation', desc: 'Fake authority figures' },
          ].map((item) => (
            <div key={item.title} className="bg-slate-900/40 border border-slate-800 rounded-xl p-4">
              <item.icon className="w-5 h-5 text-cyan-400 mb-2" />
              <h3 className="text-white text-sm font-semibold">{item.title}</h3>
              <p className="text-slate-500 text-xs mt-0.5">{item.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-6">
          <button
            onClick={() => onNavigate('education')}
            className="w-full flex items-center justify-between bg-slate-900/40 border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-cyan-400" />
              </div>
              <div className="text-left">
                <h3 className="text-white text-sm font-semibold">Learn about common scams</h3>
                <p className="text-slate-500 text-xs">Educate yourself on the tactics scammers use</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-600 group-hover:text-slate-400 transition-colors" />
          </button>
        </div>
      </div>
    </div>
  );
}
