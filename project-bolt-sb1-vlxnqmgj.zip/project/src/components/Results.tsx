import type { AnalysisResult, RiskLevel } from '@/types';
import { Shield, ShieldAlert, ShieldCheck, ShieldX, AlertTriangle, Lightbulb, ArrowRight, RotateCcw, AlertOctagon, Info } from 'lucide-react';

type View = 'home' | 'checker' | 'results' | 'history' | 'education';

interface Props {
  result: AnalysisResult;
  onNavigate: (view: View) => void;
}

const levelConfig: Record<RiskLevel, {
  label: string;
  color: string;
  bgColor: string;
  borderColor: string;
  icon: typeof Shield;
  gradient: string;
  ringColor: string;
}> = {
  low: {
    label: 'Low Risk',
    color: 'text-emerald-400',
    bgColor: 'bg-emerald-500/10',
    borderColor: 'border-emerald-500/30',
    icon: ShieldCheck,
    gradient: 'from-emerald-500 to-green-600',
    ringColor: 'text-emerald-500',
  },
  moderate: {
    label: 'Moderate Risk',
    color: 'text-amber-400',
    bgColor: 'bg-amber-500/10',
    borderColor: 'border-amber-500/30',
    icon: Shield,
    gradient: 'from-amber-500 to-yellow-600',
    ringColor: 'text-amber-500',
  },
  high: {
    label: 'High Risk',
    color: 'text-orange-400',
    bgColor: 'bg-orange-500/10',
    borderColor: 'border-orange-500/30',
    icon: ShieldAlert,
    gradient: 'from-orange-500 to-red-600',
    ringColor: 'text-orange-500',
  },
  critical: {
    label: 'Critical Risk',
    color: 'text-red-400',
    bgColor: 'bg-red-500/10',
    borderColor: 'border-red-500/30',
    icon: ShieldX,
    gradient: 'from-red-500 to-rose-700',
    ringColor: 'text-red-500',
  },
};

const severityConfig = {
  info: { color: 'text-slate-400', bg: 'bg-slate-800', icon: Info, label: 'Info' },
  warning: { color: 'text-amber-400', bg: 'bg-amber-500/10', icon: AlertTriangle, label: 'Warning' },
  danger: { color: 'text-red-400', bg: 'bg-red-500/10', icon: AlertOctagon, label: 'Danger' },
};

function RiskGauge({ score, level }: { score: number; level: RiskLevel }) {
  const config = levelConfig[level];
  const circumference = 2 * Math.PI * 70;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="relative flex items-center justify-center">
      <svg className="w-44 h-44 -rotate-90" viewBox="0 0 160 160">
        <circle cx="80" cy="80" r="70" fill="none" stroke="currentColor" strokeWidth="8" className="text-slate-800" />
        <circle
          cx="80"
          cy="80"
          r="70"
          fill="none"
          stroke="url(#gradient)"
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 1s ease-in-out' }}
        />
        <defs>
          <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" className={config.ringColor} stopColor="currentColor" />
            <stop offset="100%" className={config.ringColor} stopColor="currentColor" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className={`text-5xl font-bold ${config.color}`}>{score}</span>
        <span className="text-slate-500 text-xs uppercase tracking-wider mt-1">Risk Score</span>
      </div>
    </div>
  );
}

export default function Results({ result, onNavigate }: Props) {
  const config = levelConfig[result.riskLevel];

  return (
    <div className="min-h-screen bg-slate-950">
      <div className="max-w-3xl mx-auto px-5 pt-8 pb-20">
        <button
          onClick={() => onNavigate('checker')}
          className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-8 text-sm font-medium"
        >
          <ArrowRight className="w-4 h-4 rotate-180" />
          Check something else
        </button>

        <div className={`rounded-2xl border ${config.borderColor} ${config.bgColor} p-6 sm:p-8 mb-6`}>
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <RiskGauge score={result.riskScore} level={result.riskLevel} />
            <div className="flex-1 text-center sm:text-left">
              <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full ${config.bgColor} ${config.borderColor} border mb-3`}>
                <config.icon className={`w-4 h-4 ${config.color}`} />
                <span className={`text-sm font-semibold ${config.color}`}>{config.label}</span>
              </div>
              <p className="text-white text-lg leading-relaxed">
                {result.summary || `This ${result.inputType} was analyzed and scored ${result.riskScore}/100 (${config.label}). Review the findings below for details.`}
              </p>
              <div className="mt-4 flex flex-wrap gap-3 text-sm">
                <span className="text-slate-400">
                  Type: <span className="text-slate-300 capitalize">{result.inputType}</span>
                </span>
                <span className="text-slate-400">
                  Findings: <span className="text-slate-300">{result.findings.length}</span>
                </span>
              </div>
            </div>
          </div>
        </div>

        {result.findings.length > 0 ? (
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-white px-1">
              What We Found
            </h2>
            {result.findings.map((finding, index) => {
              const sev = severityConfig[finding.severity];
              return (
                <div
                  key={index}
                  className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-start gap-3 mb-3">
                    <div className={`w-9 h-9 rounded-lg ${sev.bg} flex items-center justify-center shrink-0`}>
                      <sev.icon className={`w-5 h-5 ${sev.color}`} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-xs font-semibold uppercase tracking-wider ${sev.color}`}>
                          {sev.label}
                        </span>
                        <span className="text-slate-600 text-xs">·</span>
                        <span className="text-slate-500 text-xs">{finding.category}</span>
                      </div>
                      <h3 className="text-white font-semibold text-base">{finding.title}</h3>
                    </div>
                  </div>
                  <p className="text-slate-400 text-sm leading-relaxed mb-3 pl-12">
                    {finding.description}
                  </p>
                  <div className="flex items-start gap-2 pl-12">
                    <Lightbulb className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                    <p className="text-cyan-100/80 text-sm leading-relaxed">
                      {finding.recommendation}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-8 text-center">
            <ShieldCheck className="w-12 h-12 text-emerald-400 mx-auto mb-4" />
            <h3 className="text-white text-lg font-semibold mb-2">No Major Red Flags Found</h3>
            <p className="text-slate-400 text-sm max-w-md mx-auto">
              We didn't find common scam warning signs in what you submitted. This doesn't guarantee it's safe — scammers constantly change tactics. Always trust your instincts and verify independently.
            </p>
          </div>
        )}

        <div className="mt-8 flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => onNavigate('checker')}
            className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold py-3.5 rounded-xl hover:shadow-lg hover:shadow-cyan-500/25 transition-all"
          >
            <RotateCcw className="w-5 h-5" />
            Check Another
          </button>
          <button
            onClick={() => onNavigate('education')}
            className="flex items-center justify-center gap-2 bg-slate-800 text-slate-300 font-medium px-5 py-3.5 rounded-xl hover:bg-slate-700 transition-all"
          >
            Learn More
          </button>
        </div>

        <div className="mt-6 bg-slate-900/40 border border-slate-800 rounded-xl p-5">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <p className="text-slate-400 text-sm leading-relaxed">
              <span className="text-amber-400 font-semibold">Important: </span>
              BeforePay provides general guidance based on common scam patterns. It is not legal, financial, or professional advice. If you've already sent money or shared personal information, contact your bank immediately and report it to the authorities.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
