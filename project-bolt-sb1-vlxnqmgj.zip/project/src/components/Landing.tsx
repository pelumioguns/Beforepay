import { Shield, ShieldCheck, ShieldAlert, ShieldX, ArrowRight, Clock, Lock, Eye, AlertTriangle, Lightbulb, BookOpen, TrendingUp, CheckCircle2, Zap, MessageSquare, Phone, Globe, CreditCard, Briefcase, Heart } from 'lucide-react';

type View = 'home' | 'checker' | 'results' | 'history' | 'education';

interface Props {
  onNavigate: (view: View) => void;
}

export default function Landing({ onNavigate }: Props) {
  return (
    <div className="min-h-screen bg-slate-950 text-white overflow-x-hidden">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-950/80 backdrop-blur-lg border-b border-slate-800/50">
        <div className="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-bold tracking-tight">BeforePay</span>
          </div>
          <div className="flex items-center gap-2 sm:gap-4">
            <button
              onClick={() => onNavigate('education')}
              className="text-slate-400 hover:text-white text-sm font-medium transition-colors hidden sm:block"
            >
              Learn
            </button>
            <button
              onClick={() => onNavigate('history')}
              className="text-slate-400 hover:text-white text-sm font-medium transition-colors hidden sm:block"
            >
              History
            </button>
            <button
              onClick={() => onNavigate('checker')}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-sm font-semibold px-4 py-2 rounded-lg hover:shadow-lg hover:shadow-cyan-500/25 transition-all"
            >
              Check Now
            </button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative pt-32 pb-20 px-5">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-[120px]" />
          <div className="absolute top-40 left-1/4 w-[300px] h-[300px] bg-blue-600/10 rounded-full blur-[100px]" />
        </div>
        <div className="relative max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900/60 border border-slate-800 mb-8">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-slate-400 text-sm font-medium">Check before you send</span>
          </div>
          <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold tracking-tight mb-6 leading-[1.05]">
            Every day, people
            <br />
            <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-blue-500 bg-clip-text text-transparent">
              lose money to scams.
            </span>
          </h1>
          <p className="text-slate-400 text-lg sm:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
            BeforePay helps you stop and check before your money leaves your hands. Paste a suspicious message, phone number, website, or payment request — we'll look for common scam warning signs and explain, in simple language, what you should worry about.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => onNavigate('checker')}
              className="group flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold px-8 py-4 rounded-xl hover:shadow-xl hover:shadow-cyan-500/30 transition-all text-lg"
            >
              <ShieldCheck className="w-6 h-6" />
              Check Before You Send
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => onNavigate('education')}
              className="flex items-center gap-2 text-slate-300 font-medium px-6 py-4 rounded-xl hover:bg-slate-900/60 transition-all"
            >
              <BookOpen className="w-5 h-5" />
              Learn the Signs
            </button>
          </div>
        </div>
      </section>

      {/* Before You Section */}
      <section className="py-16 px-5 border-t border-slate-800/50">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-center text-slate-400 text-sm font-semibold uppercase tracking-wider mb-10">
            Before you
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {[
              { label: 'Send money', icon: CreditCard },
              { label: 'Buy from a stranger', icon: ShieldAlert },
              { label: 'Pay for a job', icon: Briefcase },
              { label: 'Invest your money', icon: TrendingUp },
              { label: 'Click a link', icon: Globe },
              { label: 'Trust a stranger', icon: Eye },
            ].map((item) => (
              <div
                key={item.label}
                className="flex flex-col items-center gap-3 p-5 rounded-2xl bg-slate-900/40 border border-slate-800 hover:border-slate-700 transition-colors"
              >
                <item.icon className="w-7 h-7 text-cyan-400" />
                <span className="text-slate-300 text-sm font-medium text-center">{item.label}</span>
              </div>
            ))}
          </div>
          <p className="text-center text-slate-500 text-lg mt-10 max-w-2xl mx-auto">
            Check it with BeforePay first. Because once the money is gone, it's usually too late.
          </p>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-5 border-t border-slate-800/50">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-center mb-3 tracking-tight">How It Works</h2>
          <p className="text-slate-400 text-center text-lg mb-12 max-w-xl mx-auto">Three simple steps. No sign-up required.</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                step: '1',
                icon: MessageSquare,
                title: 'Paste it',
                desc: 'Copy any suspicious message, phone number, website, or payment request and paste it into the checker.',
              },
              {
                step: '2',
                icon: Zap,
                title: 'We analyze',
                desc: 'BeforePay scans for common scam warning signs — urgency, fake authority, payment tricks, and more — in seconds.',
              },
              {
                step: '3',
                icon: Lightbulb,
                title: 'Get clear guidance',
                desc: 'See a risk score, a plain-language summary, and specific recommendations on what to do next.',
              },
            ].map((item) => (
              <div key={item.step} className="relative bg-slate-900/60 border border-slate-800 rounded-2xl p-6">
                <div className="absolute -top-3 -left-3 w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white font-bold text-sm shadow-lg">
                  {item.step}
                </div>
                <item.icon className="w-10 h-10 text-cyan-400 mb-4 mt-2" />
                <h3 className="text-white text-lg font-semibold mb-2">{item.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* What We Detect */}
      <section className="py-20 px-5 border-t border-slate-800/50 bg-slate-900/20">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-center mb-3 tracking-tight">What We Look For</h2>
          <p className="text-slate-400 text-center text-lg mb-12 max-w-xl mx-auto">BeforePay checks for dozens of scam warning signs across multiple categories.</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { icon: AlertTriangle, title: 'Urgency & Pressure', desc: 'Artificial deadlines and panic tactics' },
              { icon: CreditCard, title: 'Payment Red Flags', desc: 'Gift cards, crypto, wire transfers, money apps' },
              { icon: ShieldAlert, title: 'Authority Impersonation', desc: 'Fake IRS, police, FBI, or bank officials' },
              { icon: Lock, title: 'Credential Harvesting', desc: 'Requests for passwords, PINs, SSNs, codes' },
              { icon: Eye, title: 'Secrecy Demands', desc: 'Asking you to keep it from family or friends' },
              { icon: TrendingUp, title: 'Investment Fraud', desc: 'Guaranteed returns, risk-free promises' },
              { icon: Briefcase, title: 'Job Scams', desc: 'Upfront fees, no-experience-required offers' },
              { icon: Heart, title: 'Romance Scams', desc: 'Love bombing followed by money requests' },
              { icon: Globe, title: 'Suspicious Links', desc: 'Shortened URLs, fake domains, raw IPs' },
            ].map((item) => (
              <div key={item.title} className="flex items-start gap-3 p-4 rounded-xl bg-slate-900/40 border border-slate-800 hover:border-slate-700 transition-colors">
                <item.icon className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-white text-sm font-semibold">{item.title}</h3>
                  <p className="text-slate-500 text-xs mt-0.5">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats / Trust */}
      <section className="py-20 px-5 border-t border-slate-800/50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-6 tracking-tight">Don't Guess. Check.</h2>
          <p className="text-slate-400 text-lg mb-12 max-w-2xl mx-auto">
            Scammers are getting smarter. BeforePay gives you a second opinion before you make a decision you might regret.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              { value: '13+', label: 'Scam categories analyzed' },
              { value: '50+', label: 'Warning sign patterns' },
              { value: '0', label: 'Sign-up or cost required' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-1">
                  {stat.value}
                </div>
                <div className="text-slate-500 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-5 border-t border-slate-800/50">
        <div className="max-w-3xl mx-auto text-center">
          <div className="relative bg-gradient-to-br from-slate-900 to-slate-800/50 border border-slate-800 rounded-3xl p-10 sm:p-14 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-blue-600/5 pointer-events-none" />
            <div className="relative">
              <ShieldCheck className="w-14 h-14 text-cyan-400 mx-auto mb-5" />
              <h2 className="text-3xl sm:text-4xl font-bold mb-4 tracking-tight">
                Check before you send.
              </h2>
              <p className="text-slate-400 text-lg mb-8 max-w-xl mx-auto">
                It takes seconds. It could save you thousands. Paste what you've received and find out if it's safe.
              </p>
              <button
                onClick={() => onNavigate('checker')}
                className="group inline-flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold px-8 py-4 rounded-xl hover:shadow-xl hover:shadow-cyan-500/30 transition-all text-lg"
              >
                <Shield className="w-6 h-6" />
                Start Checking
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 px-5 border-t border-slate-800/50">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
              <Shield className="w-4 h-4 text-white" />
            </div>
            <span className="text-slate-400 font-semibold text-sm">BeforePay</span>
          </div>
          <p className="text-slate-600 text-xs text-center sm:text-right max-w-md">
            BeforePay provides general guidance based on common scam patterns. It is not legal, financial, or professional advice. Always verify independently and contact authorities if you've been scammed.
          </p>
        </div>
      </footer>
    </div>
  );
}
