import { ArrowRight, BookOpen, ShieldAlert, CreditCard, Phone, Globe, Heart, Briefcase, TrendingUp, AlertTriangle, Lightbulb } from 'lucide-react';

type View = 'home' | 'checker' | 'results' | 'history' | 'education';

interface Props {
  onNavigate: (view: View) => void;
}

interface ScamType {
  icon: typeof ShieldAlert;
  title: string;
  description: string;
  signs: string[];
  protection: string;
  color: string;
}

const scamTypes: ScamType[] = [
  {
    icon: ShieldAlert,
    title: 'Phishing Messages',
    description: 'Fake emails, texts, or DMs pretending to be from a trusted organization to steal your information.',
    signs: ['Urgent language demanding immediate action', 'Links to fake login pages', 'Requests for passwords or verification codes', 'Generic greetings like "Dear Customer"'],
    protection: 'Never click links in unexpected messages. Type the official website address directly into your browser. Real organizations never ask for passwords or codes via message.',
    color: 'text-red-400 bg-red-500/10 border-red-500/20',
  },
  {
    icon: Phone,
    title: 'Phone Call Scams',
    description: 'Callers impersonating government agencies, banks, or tech support to pressure you into paying or sharing information.',
    signs: ['Threats of arrest, fines, or deportation', 'Demand for gift cards or wire transfers', 'Claims your account is compromised', 'Pressure to stay on the line and not hang up'],
    protection: 'Hang up immediately. Government agencies and banks never call demanding payment. Call back using the number from the official website or your card — not a number the caller gave you.',
    color: 'text-orange-400 bg-orange-500/10 border-orange-500/20',
  },
  {
    icon: CreditCard,
    title: 'Payment & Invoice Fraud',
    description: 'Fake invoices, payment demands, or refund offers designed to trick you into sending money or revealing banking details.',
    signs: ['Unexpected payment requests or invoices', 'Pressure to pay via gift cards or crypto', 'Claims of overpayment needing a refund', 'New or changed bank account details on invoices'],
    protection: 'Verify any unexpected payment request by contacting the company directly using known, trusted contact information. Never pay with gift cards or cryptocurrency.',
    color: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
  },
  {
    icon: Globe,
    title: 'Fake Websites',
    description: 'Counterfeit websites that mimic real stores, banks, or services to steal your money, card details, or login credentials.',
    signs: ['Slightly misspelled web addresses', 'Prices that seem too good to be true', 'No physical address or contact info', 'Missing HTTPS padlock or invalid certificates'],
    protection: 'Check the web address carefully for misspellings. Look for the HTTPS padlock. Search for reviews. Type URLs manually rather than clicking links.',
    color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20',
  },
  {
    icon: Heart,
    title: 'Romance Scams',
    description: 'Scammers build fake romantic relationships over weeks or months, then ask for money for emergencies, travel, or visas.',
    signs: ['Quick declarations of love', 'Inability to video chat or meet in person', 'Claims of working on oil rigs or military deployment', 'Eventual requests for money, gift cards, or flights'],
    protection: 'Never send money to someone you haven\'t met in person. Reverse-image-search their photos. Be suspicious of anyone who avoids video calls. Tell family and friends about the relationship.',
    color: 'text-pink-400 bg-pink-500/10 border-pink-500/20',
  },
  {
    icon: Briefcase,
    title: 'Job & Employment Scams',
    description: 'Fake job offers that ask you to pay upfront for materials, training, or background checks, or to reship packages.',
    signs: ['High pay for no experience or skills', 'Requests for upfront fees', 'Mystery shopper or package forwarding roles', 'Conducted entirely via text or chat apps'],
    protection: 'Never pay money to get a job. Research the company independently. Legitimate employers use official job boards and conduct interviews via verified channels.',
    color: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
  },
  {
    icon: TrendingUp,
    title: 'Investment Fraud',
    description: 'Promises of guaranteed high returns, risk-free profits, or exclusive crypto opportunities that take your money and disappear.',
    signs: ['Guaranteed returns with no risk', 'Pressure to invest quickly', 'Unsolicited investment offers', 'Requests for crypto or wire transfers'],
    protection: 'All investments carry risk — guaranteed returns don\'t exist. Verify the investment and the seller with financial regulators. Never invest based on an unsolicited message.',
    color: 'text-violet-400 bg-violet-500/10 border-violet-500/20',
  },
];

const generalTips = [
  'Slow down. Scammers create false urgency so you act before thinking.',
  'Verify independently. Use contact info you find yourself, not what the message provides.',
  'Never pay with gift cards, cryptocurrency, or wire transfers to strangers.',
  'Never share passwords, PINs, or one-time codes with anyone.',
  'Talk to someone you trust before sending money or sharing information.',
  'If it seems too good to be true, it almost certainly is.',
];

export default function Education({ onNavigate }: Props) {
  return (
    <div className="min-h-screen bg-slate-950">
      <div className="max-w-4xl mx-auto px-5 pt-8 pb-20">
        <button
          onClick={() => onNavigate('checker')}
          className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-8 text-sm font-medium"
        >
          <ArrowRight className="w-4 h-4 rotate-180" />
          Back to checker
        </button>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 mb-5 shadow-lg shadow-cyan-500/20">
            <BookOpen className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3 tracking-tight">
            Know the Signs
          </h1>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Scammers rely on you not recognizing their tactics. Learn the warning signs of common scams so you can spot them before it's too late.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-12">
          {scamTypes.map((scam) => (
            <div key={scam.title} className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 hover:border-slate-700 transition-colors">
              <div className={`inline-flex items-center justify-center w-12 h-12 rounded-xl border ${scam.color} mb-4`}>
                <scam.icon className="w-6 h-6" />
              </div>
              <h3 className="text-white text-lg font-semibold mb-2">{scam.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-4">{scam.description}</p>
              <div className="mb-4">
                <h4 className="text-slate-300 text-xs font-semibold uppercase tracking-wider mb-2">Warning Signs</h4>
                <ul className="space-y-1.5">
                  {scam.signs.map((sign, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-slate-400">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                      {sign}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="flex items-start gap-2 pt-3 border-t border-slate-800">
                <Lightbulb className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <p className="text-cyan-100/70 text-sm leading-relaxed">{scam.protection}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-br from-slate-900 to-slate-900/40 border border-slate-800 rounded-2xl p-6 sm:p-8 mb-8">
          <h2 className="text-xl font-bold text-white mb-5 flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-cyan-400" />
            Golden Rules
          </h2>
          <div className="space-y-3">
            {generalTips.map((tip, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center shrink-0">
                  <span className="text-cyan-400 text-sm font-bold">{i + 1}</span>
                </div>
                <p className="text-slate-300 text-sm leading-relaxed pt-0.5">{tip}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-red-500/5 border border-red-500/20 rounded-2xl p-6">
          <h2 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-400" />
            If You've Already Been Scammed
          </h2>
          <p className="text-slate-400 text-sm leading-relaxed mb-4">
            Act fast. Contact your bank immediately to stop or reverse payments. Change passwords for any compromised accounts. Report the scam to the authorities and relevant consumer protection agencies.
          </p>
          <button
            onClick={() => onNavigate('checker')}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold px-5 py-3 rounded-xl hover:shadow-lg hover:shadow-cyan-500/25 transition-all"
          >
            Check Something Now
          </button>
        </div>
      </div>
    </div>
  );
}
