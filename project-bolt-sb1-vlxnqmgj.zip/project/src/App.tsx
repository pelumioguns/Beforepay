import { useState } from 'react';
import Landing from '@/components/Landing';
import Checker from '@/components/Checker';
import Results from '@/components/Results';
import HistoryView from '@/components/HistoryView';
import Education from '@/components/Education';
import type { AnalysisResult, CheckHistoryItem } from '@/types';

type View = 'home' | 'checker' | 'results' | 'history' | 'education';

function App() {
  const [view, setView] = useState<View>('home');
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const handleNavigate = (next: View) => {
    window.scrollTo({ top: 0, behavior: 'instant' });
    setView(next);
  };

  const handleAnalysisComplete = (analysisResult: AnalysisResult) => {
    setResult(analysisResult);
  };

  const handleSelectHistoryItem = (item: CheckHistoryItem) => {
    const analysisResult: AnalysisResult = {
      inputType: item.input_type as AnalysisResult['inputType'],
      inputContent: item.input_content,
      riskScore: item.risk_score,
      riskLevel: item.risk_level as AnalysisResult['riskLevel'],
      findings: item.findings || [],
      summary: '',
    };
    setResult(analysisResult);
    setView('results');
  };

  if (view === 'home') {
    return <Landing onNavigate={handleNavigate} />;
  }
  if (view === 'checker') {
    return <Checker onNavigate={handleNavigate} onAnalysisComplete={handleAnalysisComplete} />;
  }
  if (view === 'results' && result) {
    return <Results result={result} onNavigate={handleNavigate} />;
  }
  if (view === 'history') {
    return <HistoryView onNavigate={handleNavigate} onSelectResult={handleSelectHistoryItem} />;
  }
  if (view === 'education') {
    return <Education onNavigate={handleNavigate} />;
  }
  return <Landing onNavigate={handleNavigate} />;
}

export default App;
